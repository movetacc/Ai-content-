"""
Downloads vertical stock video clips matching the script's b-roll keywords,
using the free Pexels Video API. Outputs output/clips/clip_0.mp4, clip_1.mp4, ...
"""
import json
import os

import requests

PEXELS_API_KEY = os.environ["PEXELS_API_KEY"]
HEADERS = {"Authorization": PEXELS_API_KEY}


def search_clip(keyword: str) -> str | None:
    """Return a direct download URL for a portrait (9:16-friendly) clip, or None."""
    resp = requests.get(
        "https://api.pexels.com/videos/search",
        headers=HEADERS,
        params={"query": keyword, "orientation": "portrait", "per_page": 5},
        timeout=30,
    )
    resp.raise_for_status()
    videos = resp.json().get("videos", [])
    if not videos:
        return None

    # Prefer a moderate-resolution HD file to keep downloads/render time reasonable.
    files = sorted(
        videos[0]["video_files"],
        key=lambda f: abs((f.get("height") or 0) - 1280),
    )
    for f in files:
        if f.get("file_type") == "video/mp4":
            return f["link"]
    return None


def download(url: str, dest: str) -> None:
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    os.makedirs("output/clips", exist_ok=True)
    saved = 0
    for i, keyword in enumerate(data["broll_keywords"]):
        url = search_clip(keyword)
        if not url:
            print(f"No clip found for '{keyword}', skipping")
            continue
        dest = f"output/clips/clip_{saved}.mp4"
        download(url, dest)
        print(f"Saved '{keyword}' -> {dest}")
        saved += 1

    if saved == 0:
        raise SystemExit("No stock footage found for any keyword — check PEXELS_API_KEY or keywords.")
