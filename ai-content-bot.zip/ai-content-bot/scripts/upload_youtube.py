"""
Uploads output/final.mp4 to YouTube as a Short. Fully automatable, free,
official API, no approval needed for your own channel.

One-time setup:
1. Google Cloud Console -> create project -> enable "YouTube Data API v3"
2. Create OAuth Client ID (Desktop app type)
3. Run this script once locally/interactively to complete the OAuth flow;
   it saves output/youtube_token.json which you then store as a GitHub
   Actions secret (YOUTUBE_TOKEN_JSON) for unattended future runs.
"""
import json
import os

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
TOKEN_PATH = "output/youtube_token.json"


def get_credentials() -> Credentials:
    token_json = os.environ.get("YOUTUBE_TOKEN_JSON")
    if token_json:
        return Credentials.from_authorized_user_info(json.loads(token_json), SCOPES)

    if os.path.exists(TOKEN_PATH):
        return Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)

    # First-time interactive setup only — not used in CI.
    client_secrets = os.environ["YOUTUBE_CLIENT_SECRETS_PATH"]
    flow = InstalledAppFlow.from_client_secrets_file(client_secrets, SCOPES)
    creds = flow.run_local_server(port=0)
    with open(TOKEN_PATH, "w") as f:
        f.write(creds.to_json())
    return creds


def upload(video_path: str, title: str, description: str) -> str:
    creds = get_credentials()
    youtube = build("youtube", "v3", credentials=creds)

    body = {
        "snippet": {
            "title": title[:100],
            "description": f"{description}\n\n#Shorts",
            "categoryId": "22",
        },
        "status": {"privacyStatus": "public", "selfDeclaredMadeForKids": False},
    }
    media = MediaFileUpload(video_path, chunksize=-1, resumable=True)
    request = youtube.videos().insert(part="snippet,status", body=body, media_body=media)
    response = request.execute()
    return response["id"]


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    video_id = upload("output/final.mp4", data["topic"], data["caption"])
    print(f"Uploaded to YouTube: https://youtube.com/shorts/{video_id}")
