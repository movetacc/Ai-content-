"""
Publishes output/final.mp4 to Instagram as a Reel via the Meta Graph API.

Automatable for YOUR OWN account without full Meta App Review (Review is
only required once other people use your app). Requirements:
- An Instagram Business or Creator account, linked to a Facebook Page
- A Meta Developer app with an Instagram access token for that account
- The video must be reachable at a public URL — Instagram fetches it,
  it can't be uploaded as raw bytes. Cheapest free hosting options:
    - Commit the .mp4 to a PUBLIC GitHub repo and use the raw.githubusercontent.com
      URL (fine for short vertical clips, well under GitHub's 100MB file limit)
    - Cloudflare R2 free tier (10GB storage, no egress fee)
  This script expects that public URL in PUBLIC_VIDEO_URL.
"""
import json
import os
import time

import requests

IG_USER_ID = os.environ["IG_USER_ID"]
IG_ACCESS_TOKEN = os.environ["IG_ACCESS_TOKEN"]
PUBLIC_VIDEO_URL = os.environ["PUBLIC_VIDEO_URL"]  # see module docstring
GRAPH_BASE = "https://graph.facebook.com/v20.0"


def create_container(caption: str) -> str:
    resp = requests.post(
        f"{GRAPH_BASE}/{IG_USER_ID}/media",
        data={
            "media_type": "REELS",
            "video_url": PUBLIC_VIDEO_URL,
            "caption": caption,
            "access_token": IG_ACCESS_TOKEN,
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


def wait_until_ready(container_id: str, timeout_s: int = 300, interval_s: int = 5) -> None:
    elapsed = 0
    while elapsed < timeout_s:
        resp = requests.get(
            f"{GRAPH_BASE}/{container_id}",
            params={"fields": "status_code", "access_token": IG_ACCESS_TOKEN},
            timeout=30,
        )
        resp.raise_for_status()
        status = resp.json().get("status_code")
        if status == "FINISHED":
            return
        if status == "ERROR":
            raise RuntimeError("Instagram failed to process the video container.")
        time.sleep(interval_s)
        elapsed += interval_s
    raise TimeoutError("Instagram container never finished processing.")


def publish(container_id: str) -> str:
    resp = requests.post(
        f"{GRAPH_BASE}/{IG_USER_ID}/media_publish",
        data={"creation_id": container_id, "access_token": IG_ACCESS_TOKEN},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["id"]


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    container_id = create_container(data["caption"])
    wait_until_ready(container_id)
    media_id = publish(container_id)
    print(f"Published to Instagram, media id: {media_id}")
