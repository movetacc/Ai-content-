"""
Turns the generated script into an AI voiceover using edge-tts (Microsoft's
free text-to-speech, no API key required). Outputs output/voice.mp3.
"""
import asyncio
import json
import os

import edge_tts

# Browse more voices with: edge-tts --list-voices
VOICE = os.environ.get("TTS_VOICE", "en-US-GuyNeural")
RATE = os.environ.get("TTS_RATE", "+8%")  # slightly faster reads better for shorts


async def synthesize(text: str, out_path: str) -> None:
    communicate = edge_tts.Communicate(text, VOICE, rate=RATE)
    await communicate.save(out_path)


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    full_text = f"{data['hook']} {data['script']}"
    os.makedirs("output", exist_ok=True)
    asyncio.run(synthesize(full_text, "output/voice.mp3"))
    print("Voice saved to output/voice.mp3")
