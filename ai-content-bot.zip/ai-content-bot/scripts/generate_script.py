"""
Generates a short-form video script (~45 seconds spoken) plus b-roll search
keywords, using OpenRouter. Outputs JSON to output/script.json.
"""
import json
import os
import re
import sys

import requests

OPENROUTER_API_KEY = os.environ["OPENROUTER_API_KEY"]
# Any OpenRouter model works here; swap for a free-tier model if you want $0 cost.
MODEL = os.environ.get("SCRIPT_MODEL", "meta-llama/llama-3.1-8b-instruct:free")

NICHE = os.environ.get("CONTENT_NICHE", "AI side hustles and making money with AI")

PROMPT = f"""You write scripts for short-form faceless videos (TikTok/YouTube Shorts/Reels)
about {NICHE}.

Return ONLY valid JSON, no markdown fences, in this exact shape:
{{
  "topic": "short catchy topic/title",
  "hook": "the first line, must grab attention in under 3 seconds",
  "script": "the full spoken script, 100-130 words, conversational, one clear payoff, soft CTA to follow for more at the end",
  "caption": "a short social media caption with 3-5 relevant hashtags",
  "broll_keywords": ["keyword1", "keyword2", "keyword3", "keyword4"]
}}

The broll_keywords should be simple, visual, stock-footage-searchable terms (e.g. "laptop typing", "city skyline", "person smiling at phone") that match the script's mood/topic — not abstract concepts.
"""


def generate() -> dict:
    resp = requests.post(
        "https://openrouter.ai/api/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": MODEL,
            "messages": [{"role": "user", "content": PROMPT}],
            "temperature": 0.9,
        },
        timeout=60,
    )
    resp.raise_for_status()
    raw = resp.json()["choices"][0]["message"]["content"].strip()

    # Strip accidental markdown fences if the model adds them anyway.
    raw = re.sub(r"^```(json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        print("Model did not return valid JSON:", raw, file=sys.stderr)
        raise

    required = {"topic", "hook", "script", "caption", "broll_keywords"}
    missing = required - data.keys()
    if missing:
        raise ValueError(f"Script JSON missing keys: {missing}")

    return data


if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    data = generate()
    with open("output/script.json", "w") as f:
        json.dump(data, f, indent=2)
    print(f"Generated script: {data['topic']}")
