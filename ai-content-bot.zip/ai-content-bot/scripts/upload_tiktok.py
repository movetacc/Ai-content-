"""
Uploads output/final.mp4 to TikTok via the official Content Posting API.

IMPORTANT: until your TikTok developer app passes audit, videos posted
through this API land as PRIVATE DRAFTS in your TikTok inbox — you still
have to open the app and tap post yourself. Public, unattended auto-posting
only unlocks after TikTok approves your app (apply at developers.tiktok.com;
takes anywhere from days to a few weeks). This script still saves you the
video-creation work either way.

Do NOT try to work around this with browser automation (Selenium/Playwright
simulating a human upload) — it violates TikTok's Terms of Service and risks
your account being banned.
"""
import json
import os

import requests

ACCESS_TOKEN = os.environ["TIKTOK_ACCESS_TOKEN"]
API_BASE = "https://open.tiktokapis.com/v2"


def init_upload(video_path: str, caption: str) -> dict:
    video_size = os.path.getsize(video_path)
    resp = requests.post(
        f"{API_BASE}/post/publish/video/init/",
        headers={
            "Authorization": f"Bearer {ACCESS_TOKEN}",
            "Content-Type": "application/json",
        },
        json={
            "post_info": {
                "title": caption[:150],
                "privacy_level": "SELF_ONLY",  # draft/private until your app is audited
                "disable_duet": False,
                "disable_comment": False,
                "disable_stitch": False,
            },
            "source_info": {
                "source": "FILE_UPLOAD",
                "video_size": video_size,
                "chunk_size": video_size,
                "total_chunk_count": 1,
            },
        },
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()["data"]


def upload_video_bytes(upload_url: str, video_path: str) -> None:
    with open(video_path, "rb") as f:
        video_bytes = f.read()
    resp = requests.put(
        upload_url,
        headers={
            "Content-Type": "video/mp4",
            "Content-Range": f"bytes 0-{len(video_bytes) - 1}/{len(video_bytes)}",
        },
        data=video_bytes,
        timeout=120,
    )
    resp.raise_for_status()


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    init_data = init_upload("output/final.mp4", data["caption"])
    upload_video_bytes(init_data["upload_url"], "output/final.mp4")
    print(f"Sent to TikTok as a draft (publish_id: {init_data['publish_id']}). Open the TikTok app to review and post.")
