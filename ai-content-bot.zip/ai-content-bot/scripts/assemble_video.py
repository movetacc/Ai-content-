"""
Assembles the final vertical (1080x1920) video: stock clips scaled/cropped to
fill the frame, looped/trimmed to match the voiceover's exact length, with the
voiceover mixed in and captions burned on screen.

Requires ffmpeg + ffprobe on PATH (preinstalled on GitHub Actions ubuntu runners).
Outputs output/final.mp4.
"""
import glob
import json
import math
import subprocess


def probe_duration(path: str) -> float:
    out = subprocess.check_output(
        [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", path,
        ]
    )
    return float(out.strip())


def build_background(clips: list[str], target_duration: float, out_path: str) -> None:
    """Scale/crop each clip to fill 1080x1920, loop the clip list until it
    covers target_duration, then trim to exactly that length."""
    scaled = []
    for i, clip in enumerate(clips):
        scaled_path = f"output/clips/scaled_{i}.mp4"
        subprocess.run(
            [
                "ffmpeg", "-y", "-i", clip,
                "-vf",
                "scale=1080:1920:force_original_aspect_ratio=increase,"
                "crop=1080:1920,setsar=1",
                "-an", "-c:v", "libx264", "-preset", "veryfast", scaled_path,
            ],
            check=True,
        )
        scaled.append(scaled_path)

    # Loop the clip list until total duration covers the voiceover.
    total = 0.0
    sequence = []
    while total < target_duration:
        for clip in scaled:
            sequence.append(clip)
            total += probe_duration(clip)
            if total >= target_duration:
                break

    concat_list = "output/clips/concat.txt"
    with open(concat_list, "w") as f:
        for clip in sequence:
            f.write(f"file '{clip.split('/')[-1]}'\n")

    subprocess.run(
        [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", concat_list,
            "-t", str(target_duration), "-c", "copy", "-fflags", "+genpts",
            out_path,
        ],
        check=True,
        cwd="output/clips",
    )


def seconds_to_srt_timestamp(t: float) -> str:
    ms = int(round((t - math.floor(t)) * 1000))
    t = int(math.floor(t))
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def build_srt(script: str, duration: float, out_path: str, words_per_chunk: int = 6) -> None:
    """Evenly distributes the script over the audio's real duration.
    No transcription needed — cheap, fast, good enough for shorts."""
    words = script.split()
    chunks = [
        " ".join(words[i:i + words_per_chunk])
        for i in range(0, len(words), words_per_chunk)
    ]
    per_chunk = duration / max(len(chunks), 1)

    with open(out_path, "w") as f:
        for i, chunk in enumerate(chunks):
            start = i * per_chunk
            end = (i + 1) * per_chunk
            f.write(f"{i + 1}\n")
            f.write(f"{seconds_to_srt_timestamp(start)} --> {seconds_to_srt_timestamp(end)}\n")
            f.write(f"{chunk}\n\n")


def burn_captions_and_audio(background: str, audio: str, srt: str, out_path: str) -> None:
    style = (
        "FontName=Arial,FontSize=14,Bold=1,PrimaryColour=&H00FFFFFF,"
        "OutlineColour=&H00000000,BorderStyle=3,Outline=2,Alignment=2,MarginV=120"
    )
    subprocess.run(
        [
            "ffmpeg", "-y", "-i", background, "-i", audio,
            "-vf", f"subtitles={srt}:force_style='{style}'",
            "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "libx264", "-preset", "veryfast", "-c:a", "aac",
            "-shortest", out_path,
        ],
        check=True,
    )


if __name__ == "__main__":
    with open("output/script.json") as f:
        data = json.load(f)

    audio_duration = probe_duration("output/voice.mp3")
    clips = sorted(glob.glob("output/clips/clip_*.mp4"))
    if not clips:
        raise SystemExit("No stock clips found in output/clips — run fetch_footage.py first.")

    build_background(clips, audio_duration, "output/clips/background.mp4")
    build_srt(data["script"], audio_duration, "output/captions.srt")
    burn_captions_and_audio(
        "output/clips/background.mp4", "output/voice.mp3", "output/captions.srt", "output/final.mp4",
    )
    print("Final video: output/final.mp4")
